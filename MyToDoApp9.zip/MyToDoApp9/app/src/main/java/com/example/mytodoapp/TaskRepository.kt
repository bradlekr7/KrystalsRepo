package com.example.mytodoapp

import android.content.Context
import androidx.lifecycle.LiveData

class TaskRepository (context: Context){
    var db: TodoDao? =AppDatabase.getDatabase(context)?.todoDao()

    fun getAllTasks(): LiveData<List<TodoModel>>? {
        return db?. getTask()
    }

    suspend fun insertTask(todoModel: TodoModel) {
        db?.insertTask(todoModel)
    }

    fun updateTask(todoModel: TodoModel) {
        db?.updateTask(todoModel)

    }

//    fun searchTask(todoModel: TodoModel) {
//        db?.searchTask(todoModel)
//    }

    fun deleteTask(uid: TodoModel) {
        db?.deleteTask(Long)
    }
        }



