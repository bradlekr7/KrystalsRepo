package com.example.mytodoapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.todoapp.R
import kotlinx.android.synthetic.main.activity_task.*
import kotlinx.android.synthetic.main.item_todo.view.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class TodoAdapter(private val onCardclick: ArrayList<TodoModel>,
                  val list: List<TodoModel>) : RecyclerView.Adapter<TodoAdapter.TodoViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {
        return TodoViewHolder(
            LayoutInflater.from(parent.context)
                .inflate(R.layout.item_todo, parent, false),

        return TodoViewHolder(View, onCardclick)

    }

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {
        holder.bind(list[position])
    }

    override fun getItemId(position: Int):Long{
        return list[position].id
    }

    class TodoViewHolder(itemView: View, private val onCardclick: (position: Int) -> Unit)
    :RecyclerView.ViewHolder(View), View.OnClickListener {

        init {
            itemView.setOnClickListener(this)

                    }

        fun bind(todoModel: TodoModel) {
            with(itemView) {
                txtShowTitle.text = todoModel.title
                txtShowTask.text = todoModel.description
                txtShowCategory.text = todoModel.category
                updateTime(todoModel.time)
                updateDate(todoModel.date)

            }

        }
        private fun updateTime(time: Long) {
            val myformat = "h:mm a"
            val sdf = SimpleDateFormat(myformat)
            itemView.txtShowTime.text = sdf.format(Date(time))

        }

        private fun updateDate(time: Long) {
            val myformat = "EEE, d MMM yyyy"
            val sdf = SimpleDateFormat(myformat)
            itemView.txtShowDate.text = sdf.format(Date(time))

        }

        override fun onClick(v:View?)  {
            val position = adapterPosition

            onCardclick(position)
        }

        private var onClickListener : OnClickListener? = null

        fun setOnClickListener(onClickListener: OnClickListener){
            this.onClickListener = onClickListener
        }

        interface OnClickListener {
            fun onClick(position: Int){

                }
            }

        }
    }


