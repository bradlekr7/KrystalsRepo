package com.example.mytodoapp

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import com.example.todoapp.R
import kotlinx.android.synthetic.main.activity_task.spinnerCategory

class UpdateTask : AppCompatActivity() {

        val repo: TaskRepository by lazy { TaskRepository(this) }

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_update_task)


            var title: EditText = findViewById(R.id.updateTitle)
            var details: EditText = findViewById(R.id.updateDetails)
            var date: EditText = findViewById(R.id.dateEdt)
            var time: EditText = findViewById(R.id.timeEdt)
            var category: Spinner= findViewById(R.id.updateSpinnercategory)
            var updateButton: Button = findViewById(R.id.UPDATE)
            var cancelButton: Button = findViewById(R.id.CANCEL)
            var deleteButton: ImageButton = findViewById(R.id.DELETE)


            title.setText(intent.getStringExtra("Title"))
            details.setText(intent.getStringExtra("Details"))
            category.setText(intent.getStringExtra("category"))
            date.setText(intent.getStringExtra("Date"))
            time.setText(intent.getStringExtra("Time"))


            updateButton.setOnClickListener {
                repo.updateTask(
                    TodoModel
                        (
                        title.text.toString(),
                        details.text.toString(),
                        spinnerCategory.selectedItem.toString(),
                        date.text.toString().toLong(),
                        time.text.toString().toLong(),
                    )
                )
                val myIntent = Intent(this, MainActivity::class.java)
                startActivity(myIntent)
            }

            cancelButton.setOnClickListener {

                val NextIntent = Intent(this, MainActivity::class.java)
                startActivity(NextIntent)  //new addition
            }

            deleteButton.setOnClickListener {
                repo.deleteTask(
                    TodoModel

                        (
                        title.text.toString(),
                        details.text.toString(),
                        spinnerCategory.selectedItem.toString(),
                        date.text.toString().toLong(),
                        time.text.toString().toLong(),
                    )
                )

                val dialogBuilder = AlertDialog.Builder(this)

                dialogBuilder.setMessage("Are you sure you want to delete this task?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", DialogInterface.OnClickListener {
                            dialog, id -> dialog.dismiss()
                    })
                    .setNegativeButton("No", DialogInterface.OnClickListener {
                            dialog, id -> dialog.cancel()
                    })

                val alert = dialogBuilder.create()
                alert.setTitle("Delete This Task?")
                alert.show()


                val IntentNext = Intent(this, MainActivity::class.java)
                startActivity(IntentNext)  //new addition
            }
        }

    }

private fun Spinner.setText(stringExtra: String?) {

}
