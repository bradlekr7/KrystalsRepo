package com.example.mytodoapp

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class ToDoViewModel (app: Application): AndroidViewModel(app) {

 val repo: TaskRepository

 val allTasks: LiveData<List<TodoModel>>?

 private val searchStr = MutableLiveData<List<TodoModel>>()
 init {
     repo = TaskRepository(app)
     allTasks = repo.getAllTasks()
 }

    fun getAllTasks() = viewModelScope.launch {
        repo.getAllTasks()
    }


//    fun search(searchText:String) : LiveData<List<TodoModel>> {
//        return  repo.search

    fun insertTask(todoModel: TodoModel) = viewModelScope.launch {
        repo.insertTask(todoModel)
    }

//    fun search(text:String) = viewModelScope.launch {
//        searchStr.value = text
//    }

//    fun getTaskbyId(todoModel: TodoModel) = viewModelScope.launch {
//        repo.getTaskbyId(todoModel)
//    }

    fun updateTask(todoModel: TodoModel) = viewModelScope.launch {
        repo.updateTask(todoModel)
    }

    fun deleteTask(todoModel: TodoModel) = viewModelScope.launch {
        repo.deleteTask(todoModel)
    }
}
