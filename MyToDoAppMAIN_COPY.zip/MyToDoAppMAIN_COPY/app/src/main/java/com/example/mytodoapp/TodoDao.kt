package com.example.mytodoapp

import android.content.ClipData
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface TodoDao {

    @Insert()
    suspend fun insertTask(todoModel: TodoModel):Long

    @Query("Select * from TodoModel where isFinished == 0")
    fun getTask():LiveData<List<TodoModel>>

    @Query("Update TodoModel Set isFinished = 1 where id=:uid")
    fun finishTask(uid:Long)

//    @Query("SELECT * FROM TodoModel ORDER BY " +
//           "CASE WHEN :isAsc = 1 THEN title END ASC," +
//           "CASE WHEN :isAsc =2 THEN title END DESC")
//        fun getAllSortedbyTitle(isAsc: Int?): Flow<LiveData<List<TodoModel>>>
//
//    @Query("SELECT * FROM TodoModel ORDER BY " +
//           "CASE WHEN :isAsc = 1 THEN category END ASC," +
//           "CASE WHEN :isAsc =2 THEN category END DESC ")
//    fun getSortedbyCategory(id: Long, isAsc: Int?): Flow<LiveData<List<TodoModel>>>
//
//    @Query("SELECT * FROM TodoModel" +
//            "WHERE id IN (:id)" +
//            "ORDER BY" +
//            "CASE WHEN :isAsc = 1 THEN title END ASC," +
//            "CASE WHEN :isAsc = 2 THEN title END DESC")
//    fun getAllSortedbyTitle(id : Long, isAsc: Int?): Flow<LiveData<List<TodoModel>>>

    // @Query("Select * from TodoModel ORDER BY id ASC LIMIT :limit OFFSET :offset")
    //fun getPagedList(limit: Int, offset: Int): LiveData<List<TodoModel>>

    @Query("Delete from TodoModel where id=:uid")
    fun deleteTask(uid:Long)
}